package adapter;
import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import hcl.com.manager.R;
import hcl.com.manager.abs.callback.PagerSelectListener;

public class MainViewPagerAdapter extends FragmentPagerAdapter {

    private final String[] TAB_TITLES = new String[]{"玩家列表", "收入", "玩家列表", "收入"};
    //Tab 图片
    private final int[] TAB_IMGS = new int[]{R.drawable.selector_tab_main_list, R.drawable.selector_tab_main_list, R.drawable.selector_tab_main_list, R.drawable.selector_tab_main_list};


    private ArrayList<Fragment> datas = new ArrayList<>();

    private ArrayList<View> pageViews = new ArrayList<>();



    //上下文
    private Context context;

    public MainViewPagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;

        initView();
    }

    //初始化Tab
    private void initView() {
        pageViews.clear();
        for (int i = 0; i < TAB_TITLES.length; i++) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.tab_main_custom, null);
            TextView itemTitle = (TextView) view.findViewById(R.id.main_tv_tab);
            itemTitle.setText(TAB_TITLES[i]);
            ImageView itemImg = (ImageView) view.findViewById(R.id.main_img_tab);
            itemImg.setImageResource(TAB_IMGS[i]);
            pageViews.add(view);
        }


    }

    @Override
    public Fragment getItem(int position) {
        return datas.get(position);
    }

    @Override
    public int getCount() {
        return datas.size();
    }

    public void setFragments(List<Fragment> mainFraments) {
        datas.clear();
        datas.addAll(mainFraments);

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return TAB_TITLES[position];
    }


    public View getPageTabView(int postion) {
        return pageViews.get(postion);
    }


}
