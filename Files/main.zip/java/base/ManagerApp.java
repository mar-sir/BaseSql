package base;

import android.app.Application;

public class ManagerApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
