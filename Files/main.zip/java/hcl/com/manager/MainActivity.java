package hcl.com.manager;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import java.util.ArrayList;
import adapter.MainViewPagerAdapter;
import butterknife.BindView;
import butterknife.ButterKnife;
import hcl.com.manager.abs.BaseToobarActivity;

import hcl.com.manager.views.fragments.mainfragments.IncomeFragment;
import hcl.com.manager.views.fragments.mainfragments.PlayersFragment;


public class MainActivity extends BaseToobarActivity {

    @BindView(R.id.mainViewPager)
    ViewPager mainViewPager;


    @BindView(R.id.mainTabLayout)
    TabLayout mainTabLayout;


    private ArrayList<Fragment> mainFraments = new ArrayList<>();

    private MainViewPagerAdapter mainViewPagerAdapter;


    @Override
    protected int ContentLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected boolean IsShowBackArrow() {
        return false;
    }

    @Override
    protected void ReBindView() {
        ButterKnife.bind(this);
        initViews();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    //c初始化视图
    private void initViews() {
        mainFraments = new ArrayList<>();
        //构造suipian
        mainFraments.add(new PlayersFragment());
        mainFraments.add(new IncomeFragment());
        mainFraments.add(new PlayersFragment());
        mainFraments.add(new IncomeFragment());
        //设置适配器
        mainViewPagerAdapter = new MainViewPagerAdapter(getSupportFragmentManager(), getApplicationContext());
        mainViewPagerAdapter.setFragments(mainFraments);
        mainViewPager.setAdapter(mainViewPagerAdapter);
        mainTabLayout.setupWithViewPager(mainViewPager);
        for (int i = 0; i < mainFraments.size(); i++) {
            mainTabLayout.getTabAt(i).setCustomView(mainViewPagerAdapter.getPageTabView(i));
        }
        SetTitle(mainTabLayout.getTabAt(0).getText().toString());
        mainTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                SetTitle(tab.getText().toString());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }


}
