package hcl.com.manager.abs;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import hcl.com.manager.R;

public abstract class BaseToobarActivity extends AppCompatActivity {



   private  FrameLayout mainContent;


    private Toolbar baseToolBar;


    private TextView titleTxt;

    //返回主要布局
    protected abstract int ContentLayout();

    //是否显示返回
    protected abstract boolean IsShowBackArrow();

    //绑定视图
    protected abstract void ReBindView();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_toobar);

        mainContent=(FrameLayout)findViewById(R.id.main_content);
        baseToolBar=(Toolbar)findViewById(R.id.toolbar_title_base);
        titleTxt=(TextView)findViewById(R.id.tv_title_base);


        setSupportActionBar(baseToolBar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        initView();


    }




    //定义一些视图
    private void initView() {
        if (IsShowBackArrow()) {
            final Drawable upArrow = getResources().getDrawable(R.drawable.common_back_ic);
            //设置左侧标签
            getSupportActionBar().setHomeAsUpIndicator(upArrow);
            // 给左上角图标的左边加上一个返回的图标 。对应ActionBar.DISPLAY_HOME_AS_UP
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            baseToolBar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });
        }
        //设置主内容布局
        int layoutId = ContentLayout();
        LayoutInflater inflater = getLayoutInflater();
        View contentView = inflater.inflate(layoutId,null);

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        mainContent.addView(contentView, layoutParams);
        ReBindView();
    }




    //自定义toobar
    protected void setCoustomToobar(int layout) {
        baseToolBar.setVisibility(View.GONE);//隐藏以前
        baseToolBar = (Toolbar) mainContent.findViewById(layout);
        setSupportActionBar(baseToolBar);
        setSupportActionBar(baseToolBar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }

    //设置监听
    protected void setToolBarMenuOnClick(Toolbar.OnMenuItemClickListener onClick) {
        if (null != onClick) baseToolBar.setOnMenuItemClickListener(onClick);
    }


    //设置标题
    protected  void SetTitle(String title){
        if (!TextUtils.isEmpty(title))titleTxt.setText(title);
    }

}
