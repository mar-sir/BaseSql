package hcl.com.manager.abs.callback;

/**
 * Created by caomin005 on 2018/8/4.
 */

public interface PagerSelectListener {

    void OnSelectTitle(String title);
}
