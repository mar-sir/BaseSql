package hcl.com.manager.views.fragments;

public class B {
}
