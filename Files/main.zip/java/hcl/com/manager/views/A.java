package hcl.com.manager.views;

public class A {
}
