package com.sean.demo.ui.a.activity;

/**
 * @author  SmartSean
 */
public class TestMsg1 {
    private String name;

    public TestMsg1(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
