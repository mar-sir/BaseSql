package com.sean.demo.ui.a.activity;

/**
 * @author  SmartSean
 */
public class TestMsg {
    private String name;

    public TestMsg(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
