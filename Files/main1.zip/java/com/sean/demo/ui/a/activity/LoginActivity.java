package com.sean.demo.ui.a.activity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sean.demo.R;
import com.sean.demo.ui.BaseActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LoginActivity extends BaseActivity {

    private Animation loadingAnim;
    private Animation hideAnim;
    @BindView(R.id.loading_loginImg)
    ImageView loadImg;


    @BindView(R.id.login_progress_liner)
    LinearLayout progressLinear;
    @BindView(R.id.login_info_linear)
    LinearLayout loginLinear;
    @BindView(R.id.login_forget_psw)
    TextView forgetPswTxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_login);

        ButterKnife.bind(this);

        setBackArrow();

        initAnim();
    }

    private void initAnim() {
        if (loadingAnim == null) {
            loadingAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_loading);
            hideAnim=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_hide);
        }


    }


    public void ForgetPassWord(View view) {
        Toast.makeText(getApplicationContext(), "忘记了密码", Toast.LENGTH_SHORT).show();
    }

    public void StartLogin(View view) {
        progressLinear.setVisibility(View.VISIBLE);
        loginLinear.setVisibility(View.GONE);

        forgetPswTxt.setVisibility(View.GONE);
        loadImg.startAnimation(loadingAnim);
        loginLinear.setAnimation(hideAnim);
        forgetPswTxt.setAnimation(hideAnim);
    }
}
